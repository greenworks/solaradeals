<?php
// no direct access
defined( '_JEXEC' ) or die( ';)' );

jimport('joomla.application.component.controller');

/**
 * scmeta default Controller
 *
 * @package    scmeta
 * @subpackage Controllers
 */
class sjmetaController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
		
	}
	
}// class