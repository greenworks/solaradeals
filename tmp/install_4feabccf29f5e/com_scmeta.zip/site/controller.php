<?php
/**
 * @version $Id: header.php 248 2008-05-23 10:40:56Z elkuku $
 * @package		scmeta
 * @subpackage	
 * @author		EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author		Deepak Patil {@link http://www.tekdi.net}
 * @author		Created on 12-Jan-2009
 */

// no direct access
defined( '_JEXEC' ) or die( ';)' );

jimport('joomla.application.component.controller');

/**
 * scmeta default Controller
 *
 * @package    scmeta
 * @subpackage Controllers
 */
class scmetaController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
	}// function
	
}// class