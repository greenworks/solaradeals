<?php
// no direct access
defined( '_JEXEC' ) or die( ';)' );

jimport('joomla.application.component.controller');

/* scmeta default Controller */
class scmetaController extends JController
{
	/* Method to display the view */
	function display()
	{
		parent::display();
		
	}
	
}// class
